from src.transformation.dim_location import transform_dim_location
from src.transformation.utils.save_parquet_to_s3 import write_parquet_to_s3

import boto3
import pandas as pd
from io import BytesIO

s3 = boto3.client("s3")
BUCKETNAME = 's3-ingestion-bucket-team-galena'

# util function to get timestamp of most recent ingestion
def get_timestamp(table):
    
    response = s3.get_object(Bucket=BUCKETNAME, Key='ingestion/last_ingestion_timestamp.txt')
    timestamps = response['Body'].read().decode('utf-8')

    lines = [line.strip() for line in timestamps.splitlines() if line.strip()] # split into lines

    table_timestamp = [line for line in lines if line.startswith(f"{table}_")] # find timestamp for specific table

    if not table_timestamp:
        raise ValueError("No timestamp found for '{table}'")

    return table_timestamp

# util function to read in most recent data for ingested table
def read_most_recent_ingestion(table):

    timestamp = get_timestamp(table)

    response = s3.get_object(Bucket=BUCKETNAME, Key=f"{timestamp}.parquet") # get most recent ingestion file for table

    table_data = BytesIO(response["Body"].read())

    return pd.read_parquet(table_data) # read in parquet file


# Transformation for dim_location
df_address = pd.DataFrame({
    "address_id": [1],
    "address_line_1": ["123 High St"],
    "address_line_2": [None],
    "district": ["Central"],
    "city": ["London"],
    "postal_code": ["E1 6AN"],
    "country": ["UK"],
    "phone": ["0123456789"],
    "created_at": ["2024-01-01"],
    "last_updated": ["2024-01-02"],
})

df_location = transform_dim_location(df_address)

write_parquet_to_s3(
    df_location,
    bucket="s3-transformation-bucket-team-galena",
    key_prefix="dim_location"
)