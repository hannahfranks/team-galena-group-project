"""
Test files dedicated to individual (stand-alone) DataFrame methods

Ideally these files/tests should correspond 1-to-1 with tests.series.methods

These may also present opportunities for sharing/de-duplicating test code.
"""
